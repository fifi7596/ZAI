from rest_framework.test import APITestCase, APIClient
from rest_framework.reverse import reverse
from . import views
from rest_framework import status
from .models import CarBrand
from django.utils.http import urlencode
from django import urls
from django.contrib.auth.models import User



class CarBrandTests(APITestCase):
    def post_car_brand(self, brand):
        url = reverse(views.CarBrandList.view_name)
        data = {'brand': brand}
        response = self.client.post(url, data, format='json')
        return response

    def test_post_and_get_car_brand(self):
        new_car_brand_name = 'Mazda'
        response = self.post_car_brand(new_car_brand_name)
        print("PK {0}".format(CarBrand.objects.get().pk))
        assert response.status_code == status.HTTP_201_CREATED
        assert CarBrand.objects.count() == 1
        assert CarBrand.objects.get().brand == new_car_brand_name

    def test_post_existing_car_brand_name(self):
        url = reverse(views.CarBrandList.view_name)
        new_car_brand_name = 'duplikatMazda'
        data = {'brand':new_car_brand_name}
        response_one = self.post_car_brand(new_car_brand_name)
        assert response_one.status_code == status.HTTP_201_CREATED
        response_two = self.post_car_brand(new_car_brand_name)
        print(response_two)
        assert response_two.status_code == status.HTTP_400_BAD_REQUEST

    def test_get_book_categories_collection(self):
        new_car_brand_name = 'Super Copter'
        self.post_car_brand(new_car_brand_name)
        url = reverse(views.CarBrandList.view_name)
        response = self.client.get(url, format='json')
        assert response.status_code == status.HTTP_200_OK
        assert response.data['count'] == 1
        assert response.data['results'][0]['brand'] == new_car_brand_name




# pytest tests.py