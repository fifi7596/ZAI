from django.urls import path
# from .views import CarList, CarBrandList, CarDetail, CarBrandDetail
from . import views

urlpatterns = [
    path('car-brands', views.CarBrandList.as_view(), name=views.CarBrandList.view_name),
    path('car-brands/<int:pk>', views.CarBrandDetail.as_view(), name=views.CarBrandDetail.view_name),
    path('cars', views.CarList.as_view(), name=views.CarList.view_name),
    path('cars/<int:pk>', views.CarDetail.as_view(), name=views.CarDetail.view_name),
    path('', views.ApiRoot.as_view(), name=views.ApiRoot.view_name),
]
