from .models import CarBrand, Car
from .serializers import CarBrandSerializer, CarSerializer
from rest_framework import generics
from rest_framework.response import Response
from rest_framework.reverse import reverse
from rest_framework import permissions
from .custompermission import IsOwnerOrReadOnly


class CarBrandList(generics.ListCreateAPIView):
    queryset = CarBrand.objects.all()
    serializer_class = CarBrandSerializer
    view_name = 'carbrand-list'


class CarBrandDetail(generics.RetrieveUpdateDestroyAPIView):
    queryset = CarBrand.objects.all()
    serializer_class = CarBrandSerializer
    view_name = 'carbrand-detail'


class CarList(generics.ListCreateAPIView):
    queryset = Car.objects.all()
    serializer_class = CarSerializer
    view_name = 'car-list'
    permission_classes = [IsOwnerOrReadOnly]
    def perform_create(self, serializer):
        serializer.save(owner=self.request.user)

class CarDetail(generics.RetrieveUpdateDestroyAPIView):
    queryset = Car.objects.all()
    serializer_class = CarSerializer
    view_name = 'car-detail'
    permission_classes = [permissions.IsAuthenticatedOrReadOnly]

class ApiRoot(generics.GenericAPIView):
    view_name = 'api-view'
    def get(self, request, *args, **kwargs):
        return Response({
            'car-brands': reverse(CarBrandList.view_name, request=request),
            'cars': reverse(CarList.view_name, request=request),
        })
