from django.db import models


class CarBrand(models.Model):
    brand = models.CharField(max_length=50, unique=True)

    class Meta:
        ordering = ('brand',)
    
    def __str__(self):
        return self.brand


class Car(models.Model):
    model = models.CharField(max_length=100)
    year = models.IntegerField()
    engine_type = models.CharField(max_length=100)
    engine_cap = models.FloatField()
    price = models.DecimalField(max_digits=10, decimal_places=2)
    brand = models.ForeignKey(CarBrand, related_name='cars', on_delete=models.SET_NULL, null=True)
    owner = models.ForeignKey('auth.User', related_name='books', on_delete=models.CASCADE)

    class Meta:
        ordering = ('brand', 'model', 'year')

    def __str__(self):
        return self.brand, self.model
