from rest_framework import serializers
from .models import CarBrand, Car


class CarBrandSerializer(serializers.HyperlinkedModelSerializer):
    cars = serializers.HyperlinkedRelatedField(many=True, read_only=True, view_name='car-detail')
    class Meta:
        model = CarBrand
        fields = ['id', 'url', 'brand', 'cars']


class CarSerializer(serializers.HyperlinkedModelSerializer):
    brand=serializers.SlugRelatedField(queryset=CarBrand.objects.all(), slug_field='brand')
    owner=serializers.ReadOnlyField(source='owner.username')
    class Meta:
        model = Car
        fields = ['id', 'url', 'model', 'year', 'engine_type', 'engine_cap', 'price', 'brand', 'owner']
