from django.contrib import admin
from .models import Car, CarBrand

admin.site.register(Car)
admin.site.register(CarBrand)
